# bismillah-fart-main-frame-shit
my dots me only okay

WEIRDBAR:
![weirdbar](https://github.com/user-attachments/assets/a51486ec-fafb-4466-bcab-45cd2befe163)

download this in the "Weirdbar" folder and you need apple-fonts package
